import React from 'react';
import editarIcon from '@/assets/images/Editar.png';
import borrarIcon from '@/assets/images/Borrar.png';

export interface ColumnDef<T> {
  header: string;
  accessorKey?: keyof T;
  render?: (item: T) => React.ReactNode;
  headerClassName?: string;
  cellClassName?: string;
}

interface BaseTableProps<T> {
  data: T[];
  columns: ColumnDef<T>[];
  isLoading?: boolean;
  emptyMessage?: string;
  wrapperClassName?: string;
  tableClassName?: string;
  actionsClassName?: string;
  onEdit?: (item: T) => void;
  onDelete?: (item: T) => void;
  canEdit?: boolean;
  canDelete?: boolean;
  canEditItem?: (item: T) => boolean;
  canDeleteItem?: (item: T) => boolean;
  customActions?: (item: T) => React.ReactNode;
  currentPage?: number;
  totalPages?: number;
  onPageChange?: (page: number) => void;
}

export const BaseTable = <T extends { id: number | string }>({
  data,
  columns,
  isLoading = false,
  emptyMessage = 'No se encontraron registros',
  wrapperClassName = '',
  tableClassName = 'min-w-full text-center',
  actionsClassName = 'flex w-max items-center justify-center gap-2 mx-auto',
  onEdit,
  onDelete,
  canEdit = true,
  canDelete = true,
  canEditItem,
  canDeleteItem,
  customActions,
  currentPage = 1,
  totalPages = 1,
  onPageChange,
}: BaseTableProps<T>) => {
  const hasActions = Boolean(onEdit || onDelete || customActions);
  const visiblePages = Array.from(
    new Set(
      [1, currentPage - 1, currentPage, currentPage + 1, totalPages].filter(
        (page) => page >= 1 && page <= totalPages,
      ),
    ),
  ).sort((left, right) => left - right);

  return (
    <div
      className={`flex flex-col overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm ${wrapperClassName}`.trim()}
    >
      <div className="border-b border-slate-100 bg-slate-50/80 px-4 py-2 text-xs font-medium text-slate-500 sm:hidden">
        Desliza horizontalmente para ver todas las columnas.
      </div>

      <div className="overflow-x-auto overscroll-x-contain">
        <table className={tableClassName}>
          <thead className="border-b border-slate-200 bg-slate-50">
            <tr>
              {columns.map((col, index) => (
                <th
                  key={index}
                  className={[
                    'whitespace-nowrap px-4 py-3 text-xs font-semibold uppercase tracking-wide text-slate-600',
                    col.headerClassName ?? '',
                  ].join(' ').trim()}
                >
                  {col.header}
                </th>
              ))}
              {hasActions && (
                <th className="whitespace-nowrap px-4 py-3 text-xs font-semibold uppercase tracking-wide text-slate-600">
                  Acciones
                </th>
              )}
            </tr>
          </thead>

          <tbody>
            {isLoading ? (
              <tr>
                <td colSpan={columns.length + (hasActions ? 1 : 0)} className="px-4 py-6 text-center text-sm text-slate-600">
                  Cargando información...
                </td>
              </tr>
            ) : data.length === 0 ? (
              <tr>
                <td colSpan={columns.length + (hasActions ? 1 : 0)} className="px-4 py-6 text-center text-sm text-slate-600">
                  {emptyMessage}
                </td>
              </tr>
            ) : (
              data.map((item) => (
                <tr key={item.id} className="border-b border-slate-100 transition-colors hover:bg-slate-50">
                  {columns.map((col, colIndex) => (
                    <td
                      key={colIndex}
                      className={[
                        'px-4 py-3 text-sm text-slate-700 align-top',
                        col.cellClassName ?? '',
                      ].join(' ').trim()}
                    >
                      {col.render ? col.render(item) : col.accessorKey ? String(item[col.accessorKey]) : null}
                    </td>
                  ))}

                  {hasActions && (
                    <td className="whitespace-nowrap px-4 py-3">
                      <div className={actionsClassName}>
                        {onEdit && canEdit && (
                          canEditItem == null || canEditItem(item) ? (
                            <button
                              type="button"
                              title="Editar"
                              className="rounded-md border border-slate-300 p-1.5 text-slate-700 transition-colors hover:bg-slate-100"
                              onClick={() => onEdit(item)}
                            >
                              <img src={editarIcon} alt="Editar" className="h-5 w-5" />
                            </button>
                          ) : null
                        )}

                        {customActions && customActions(item)}

                        {onDelete && canDelete && (
                          canDeleteItem == null || canDeleteItem(item) ? (
                            <button
                              type="button"
                              title="Eliminar"
                              className="rounded-md border border-slate-300 p-1.5 text-slate-700 transition-colors hover:bg-slate-100"
                              onClick={() => onDelete(item)}
                            >
                              <img src={borrarIcon} alt="Eliminar" className="h-5 w-5" />
                            </button>
                          ) : null
                        )}
                      </div>
                    </td>
                  )}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {!isLoading && totalPages > 1 && (
        <div className="flex flex-col gap-3 border-t border-slate-200 bg-slate-50 px-4 py-4 sm:flex-row sm:items-center sm:justify-center sm:px-6">
          <div className="flex flex-wrap items-center justify-center gap-2">
            <button
              type="button"
              onClick={() => onPageChange?.(currentPage - 1)}
              disabled={currentPage === 1}
              className="inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 shadow-sm transition hover:border-slate-400 hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <span aria-hidden="true">←</span>
              Anterior
            </button>

            <div className="flex items-center gap-2">
              {visiblePages.map((page) => {
                const isActive = page === currentPage;

                return (
                  <button
                    key={page}
                    type="button"
                    onClick={() => onPageChange?.(page)}
                    aria-current={isActive ? 'page' : undefined}
                    className={[
                      'inline-flex h-10 min-w-10 items-center justify-center rounded-xl px-3 text-sm font-semibold transition',
                      isActive
                        ? 'bg-[#312C85] text-white shadow-sm'
                        : 'border border-slate-300 bg-white text-slate-700 hover:border-slate-400 hover:bg-slate-100',
                    ].join(' ')}
                  >
                    {page}
                  </button>
                );
              })}
            </div>

            <button
              type="button"
              onClick={() => onPageChange?.(currentPage + 1)}
              disabled={currentPage === totalPages}
              className="inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 shadow-sm transition hover:border-slate-400 hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-50"
            >
              Siguiente
              <span aria-hidden="true">→</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
